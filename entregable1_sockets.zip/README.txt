ViewNetSend
Para compilar: g++ -Wall socket.cpp ViewNetSend.cpp -o 
Para ejecutar: ./VNsend

ViewNetReceive
Para compilar: g++ -Wall socket.cpp ViewNetReceive.cpp -o VNreceive
Para ejecutar: ./VNreceive