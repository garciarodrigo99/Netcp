#include <system_error>

#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "socket.hpp"

int protected_main(int argc, char* argv[]){

sockaddr_in local_address = make_ip_address(6000,"127.0.0.1");
sockaddr_in external_address = make_ip_address(6001,"127.0.0.1");

Socket local_socket(local_address);

Message receive_message;


while (true){
   local_socket.receive_from(receive_message, external_address);
   std::cout << receive_message.text.data() << std::endl;
}

return 0;

}

int main(){

try{
    return protected_main();
}
catch(const std::exception& e){
    std::cerr << e.what() << '\n';
    return 1;
}
catch(std::system_error& e) {
    std::cerr << "error" << ": " << e.what() << '\n';
    return 2;
}
return 0;
}