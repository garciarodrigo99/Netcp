#include <system_error>

#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "socket.hpp"

int protected_main(){

sockaddr_in local_address = make_ip_address(6000,"127.0.0.1");
sockaddr_in external_address = make_ip_address(6001,"127.0.0.1");

Socket external_socket(external_address);

//char buffer[200];

int fd = open("prueba.txt", O_RDONLY);
if (fd < 0){
    std::cerr << "No se pudo abrir el fichero: " << std::strerror(errno) << '\n';
    return 2;
}

Message external_message;
while (read(fd,&external_message, external_message.text.size()) != 0){
    external_socket.send_to(external_message,local_address);
}
close(fd);


return 0;
}

int main(){

try{
    return protected_main();
}
catch(const std::exception& e){
    std::cerr << e.what() << '\n';
    return 1;
}
catch(std::system_error& e) {
    std::cerr << "error" << ": " << e.what() << '\n';
    return 2;
}
return 0;
}