#include <array>

struct Message
{
	//...
	std::array<char, 1024> text;
	//...
};