#include "socket.hpp"

Socket::Socket(const sockaddr_in& address){

	fd_ = socket(AF_INET,SOCK_DGRAM,0);

  if (fd_ < 0){
    throw std::system_error(errno,std::system_category(),
                          "No se pudo crear el socket.");
  } else
    int br = bind(fd_, reinterpret_cast<const sockaddr*>(&address),
                          sizeof(address));
    if (br < 0){
      throw std::system_error(errno,std::system_category(),"Bind falló.");
    }
}




Socket::~Socket(){}



int Socket::GetFd(){
  return fd_;
}



int Socket::GetBindResult(){
  return bind_result_;
}



int Socket::GetSendResult(){
  return send_result_;
}



int Socket::GetRecResult(){
  return rec_result_;
}



void Socket::send_to(const Message& message, const sockaddr_in& address){

  int st = sendto(fd_, &message, sizeof(message), 0, 
        reinterpret_cast<const sockaddr*>(&address), sizeof(address));
  if (st < 0){
    throw std::system_error(errno,std::system_category(),"sendto() falló.");
    
  }
  

}



void Socket::receive_from(Message& message, sockaddr_in& address){
  socklen_t addr_len = sizeof(address);

  int rf = recvfrom(fd_, &message, sizeof(message), 0,
          reinterpret_cast<sockaddr*>(&address), &addr_len);
  if (rf < 0){
    throw std::system_error(errno,std::system_category(),
                          "receive_from() falló.");
  }
  
}

//-----------------------------------------------------------------------------

sockaddr_in make_ip_address(int port, const std::string& ip_address){

  sockaddr_in local_address{};
  local_address.sin_family = AF_INET;                       // UDP
  local_address.sin_port = htons(port);                     // Nº de puerto pasado a formato interfaz de comunicaciones

  if (ip_address.empty())
    local_address.sin_addr.s_addr = htonl(INADDR_ANY);      // Para IP vacía, asignar una por defecto
  else 
    inet_aton(ip_address.c_str(), &local_address.sin_addr);

  return local_address;
}