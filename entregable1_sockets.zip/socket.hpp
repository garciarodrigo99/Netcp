#include <iostream>
#include <cstring>
#include <string>
#include <stdexcept>
#include <system_error>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "message.hpp"

class Socket
{

	public:
		// Constructor y destructor
		Socket(const sockaddr_in&);
		~Socket();

		//Getters
		// int GetFd(void);
		// int GetBindResult(void);
		// int GetSendResult(void);
		// int GetRecResult(void);

		void send_to(const Message&, const sockaddr_in&);
		void receive_from(Message&, sockaddr_in&);

	private:
		int fd_;
		// int bind_result_;
		// int send_result_;
		// int rec_result_;

};

sockaddr_in make_ip_address(int port, const std::string& ip_address = std::string());
